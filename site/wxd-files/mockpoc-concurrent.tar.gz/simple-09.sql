-- simple-09.sql
-- retrieve products with a unit cost higher than the average unit cost:

SELECT *
FROM dist_inventory_fact
WHERE unit_cost >
    (SELECT avg(average_unit_cost)
     FROM dist_inventory_fact)
  AND month_key BETWEEN ? AND ? -- 201204 and 201206 201207 and 201209 201210 and 201212
ORDER BY product_key
--limit 100
;
