-- complex-06.sql
-- retrieves information about returned items, including product details, order methods, and return reasons
-- for different languages.

SELECT product_name,
       introduction_date,
       order_method_en,
       reason_description_en
FROM sls_product_lookup pl,
     sls_product_dim sales,
     sls_order_method_dim ord,
     dist_return_reason_dim rr,
     dist_returned_items_fact ret
WHERE pl.product_number=sales.product_number
  AND ret.product_key=sales.product_key
  AND rr.return_reason_key=ret.return_reason_key
--AND pl.product_language = 'EN' -- AR CS DA DE EL EN ES FI FR HR HU ID IT JA KK KO MS NL NO PL PT RO RU SC SL SV TC TH TR
  AND pl.product_language = ?    -- AR CS DA DE EL EN ES FI FR HR HU ID IT JA KK KO MS NL NO PL PT RO RU SC SL SV TC TH TR
  AND ret.order_method_key=ord.order_method_key;
