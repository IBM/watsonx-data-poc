-- complex-03.sql
-- calculate total sales per organization by year with percentage of sales change year over year

WITH organizationtotalsales AS(
    SELECT
        go.organization_code,
        EXTRACT(YEAR FROM to_date(s.order_day_key::varchar(8), 'YYYYMMDD')) AS sale_year,
        SUM(s.sale_total) AS org_total_sales
    FROM
        sls_sales_fact s
        JOIN go_org_dim go
            ON s.organization_key = go.organization_key
    GROUP BY
        go.organization_code,
        sale_year
) -- Select relevant columns and calculate percentage change from the prior year
SELECT
    ots.organization_code,
    ots.sale_year,
    ots.org_total_sales,
    lag(ots.org_total_sales) OVER(PARTITION BY
        ots.organization_code ORDER BY
        ots.sale_year) AS previous_year_sales,
    CASE WHEN lag(ots.org_total_sales) OVER(PARTITION BY
            ots.organization_code ORDER BY
            ots.sale_year) IS NOT NULL
            THEN (ots.org_total_sales - lag(ots.org_total_sales) OVER(PARTITION BY
                ots.organization_code ORDER BY
                ots.sale_year)) / lag(ots.org_total_sales) OVER(PARTITION BY
            ots.organization_code ORDER BY
            ots.sale_year) * 100
        ELSE NULL
        END AS percentage_change
FROM
    organizationtotalsales ots
ORDER BY
    ots.organization_code,
    ots.sale_year ;
