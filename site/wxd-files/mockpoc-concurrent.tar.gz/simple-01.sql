-- simple-01.sql
-- select 100 rows from SLS_PRODUCT_DIM by year

SELECT *
FROM sls_product_dim
WHERE extract(YEAR
              FROM introduction_date) = ? -- 2006 2007 2008 2009 2010 2011 2012 
--LIMIT 100
;
