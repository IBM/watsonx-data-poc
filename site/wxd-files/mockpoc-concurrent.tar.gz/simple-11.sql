-- simple-11.sql
-- retrieve orders placed on a specified date

SELECT extract(YEAR
               FROM gd.day_date) AS YEAR,
       extract(MONTH
               FROM gd.day_date) AS MONTH,
       sum(sf.sale_total) AS total_sales
FROM sls_sales_fact sf
JOIN go_time_dim gd ON sf.order_day_key = gd.day_key
WHERE extract(YEAR
              FROM gd.day_date) = ? -- 2009 2010 2011 2012
GROUP BY YEAR,
         MONTH
ORDER BY YEAR,
         MONTH;
