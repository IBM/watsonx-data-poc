-- simple-08.sql
-- retrieves specific columns from the SLS_SALES_FACT table
-- for sales where the sale_total is greater than X

SELECT sales_order_key,
       product_key,
       quantity,
       sale_total
FROM sls_sales_fact
WHERE sale_total > ? -- 1000 5000 10000 25000 50000 75000 100000 150000 200000
--LIMIT 1000
;
