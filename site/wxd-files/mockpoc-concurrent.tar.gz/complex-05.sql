-- complex-05.sql
-- sales data based on different order methods

SELECT o.order_method_en,
       g.month_en,
       g.current_year,
       sum(s.sale_total) AS total_sales,
       count(s.sales_order_key) AS num_orders,
       avg(s.unit_price) AS avg_unit_price,
       avg(s.gross_margin) AS avg_gross_margin
FROM sls_sales_fact s
JOIN go_time_dim g ON s.order_day_key = g.day_key
JOIN sls_order_method_dim o ON s.order_method_key = o.order_method_key
WHERE g.current_year = ? -- 2010, 2011, 2012, 2013
--AND g.month_en BETWEEN 'January' AND 'March' -- 'April' and 'June'  'July' and 'September'  'October' and 'December'
  AND g.month_en BETWEEN     ?     AND    ?    -- 'April' and 'June'  'July' and 'September'  'October' and 'December'
GROUP BY o.order_method_en,
         g.month_en,
         g.current_year
ORDER BY g.current_year,
         g.month_en,
         o.order_method_en;
