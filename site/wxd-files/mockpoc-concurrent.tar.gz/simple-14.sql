-- simple-14.sql
-- total quantity shipped per organization and branch

SELECT organization_key,
       branch_key,
       sum(quantity_shipped) AS total_quantity_shipped
FROM dist_inventory_fact
GROUP BY organization_key,
         branch_key
ORDER BY total_quantity_shipped DESC;
