-- complex-04.sql
-- analyze sales and inventory data for products that meet specific criteria

WITH sales AS
  (SELECT sf.product_key AS prod_key,
          sf.quantity AS quantity,
          pll.product_line_en AS product,
          pbl.product_brand_fr AS brand
   FROM sls_order_method_dim AS md,
        sls_product_dim AS pd,
        sls_product_line_lookup AS pll,
        sls_product_brand_lookup AS pbl,
        emp_employee_dim AS ed,
        sls_sales_fact AS sf -- 500,000 rows
   WHERE pd.product_key = sf.product_key
     AND pd.product_number > ? -- 100 1000 5000 10000 25000 50000 100000 150000
     AND pd.base_product_key > ?  -- 10 20 30 40 50 60 70 80 90 100
     AND md.order_method_key = sf.order_method_key
     AND md.order_method_code > ? -- 1 2 3 4 5 6 7
     AND ed.employee_key = sf.employee_key
     AND ed.manager_code1 > ? -- 10 20 30 40 50 100 1000 5000 10000 100000
     AND pll.product_line_code = pd.product_line_code
     AND pbl.product_brand_code = pd.product_brand_code
  ),
inventory AS
  (SELECT if.product_key AS prod_key,
          od.organization_code1 AS org_code,
          od.organization_level AS org
   FROM go_branch_dim AS bd,
        go_org_dim AS od,
        dist_inventory_fact AS IF -- 50,000 rows
   WHERE if.branch_key = bd.branch_key
     AND bd.branch_code > ? --  6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
     AND od.organization_key = if.organization_key
  )
SELECT s.prod_key AS sales_prod_key,
       s.quantity,
       s.brand,
       i.org,
       i.org_code,
       s.product
FROM sales s
JOIN inventory i ON s.prod_key = i.prod_key
--LIMIT 100
;

