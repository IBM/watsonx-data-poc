-- simple-15.sql
-- average unit cost for each product

SELECT product_key,
       avg(unit_cost) AS average_unit_cost
FROM dist_inventory_fact
GROUP BY product_key;
