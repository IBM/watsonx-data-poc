-- simple-02.sql
-- retrieves order method information from the SLS_ORDER_METHOD_DIM table
-- and orders the results by ORDER_METHOD_KEY and ORDER_METHOD_CODE

SELECT order_method_key,
       order_method_code,
       order_method_en
FROM sls_order_method_dim
ORDER BY 1,
         2;
