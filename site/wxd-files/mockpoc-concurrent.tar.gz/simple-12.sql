-- simple-12.sql
-- retrieves total sales by year and quarter

SELECT CASE gd.current_quarter
           WHEN 1 THEN 'Q1'
           WHEN 2 THEN 'Q2'
           WHEN 3 THEN 'Q3'
           WHEN 4 THEN 'Q4'
           ELSE NULL
       END AS QUARTER,
       extract(YEAR
               FROM gd.day_date) AS YEAR,
       sum(sf.sale_total) AS total_sales
FROM sls_sales_fact sf
JOIN go_time_dim gd ON sf.order_day_key = gd.day_key
GROUP BY YEAR,
         QUARTER
ORDER BY YEAR,
         QUARTER;
