-- intermediate-02.sql
-- count the total number of employees and the number of employees with EMPLOYEE_LEVEL above X for each branch

SELECT branch_code,
       count(*) AS total_employees,
       sum(CASE
               WHEN employee_level > ? THEN 1  --1 2 3 4 5 6 7 8 9 10
               ELSE 0
           END) AS employees_above_level 
FROM emp_employee_dim
GROUP BY branch_code
ORDER BY branch_code,
         total_employees ;
