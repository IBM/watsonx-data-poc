-- simple-04.sql
-- count number of orders for each WAREHOUSE_BRANCH_CODE

SELECT warehouse_branch_code,
       count(*) AS order_count
FROM sls_sales_order_dim
GROUP BY warehouse_branch_code
HAVING order_count < ? -- 5000 10000 15000 20000 50000 
ORDER BY order_count DESC;
