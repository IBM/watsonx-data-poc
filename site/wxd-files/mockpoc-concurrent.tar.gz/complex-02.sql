-- complex-02.sql
-- calculate total sales and average gross margin per product with product details

WITH productsalesdetails AS
  (SELECT p.product_key,
          p.product_line_code,
          p.product_type_key,
          p.product_type_code,
          p.introduction_date,
          p.discontinued_date,
          pl.product_name, -- Added for product name
 sum(s.sale_total) AS total_sales,
 avg(s.gross_margin) AS avg_gross_margin
   FROM sls_sales_fact s
   JOIN sls_product_dim p ON s.product_key = p.product_key
   JOIN sls_product_lookup pl ON p.product_number = pl.product_number -- Added join for product name
   GROUP BY p.product_key,
            p.product_line_code,
            p.product_type_key,
            p.product_type_code,
            p.introduction_date,
            p.discontinued_date,
            pl.product_name -- Added for product name
) -- Select relevant columns
SELECT psd.product_key,
       psd.product_line_code,
       psd.product_type_key,
       psd.product_type_code,
       psd.introduction_date,
       psd.discontinued_date,
       psd.product_name, -- Added for product name
 psd.total_sales,
 psd.avg_gross_margin
FROM productsalesdetails psd
ORDER BY psd.product_key;
