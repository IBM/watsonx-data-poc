-- complex-08.sql
-- analyze sales and inventory data for products that meet specific criteria

 WITH sales AS
  (SELECT sf.*
   FROM sls_order_method_dim AS md,
        sls_product_dim AS pd,
        emp_employee_dim AS ed,
        sls_sales_fact AS sf
   WHERE pd.product_key = sf.product_key 
     AND pd.product_number > ? -- 100 1000 5000 10000 25000 50000 100000 150000
     AND pd.base_product_key > ? -- 10 20 30 40 50 60 70 80 90 100
     AND md.order_method_key = sf.order_method_key 
     AND md.order_method_code > ? -- 1 2 3 4 5 6 7
     AND ed.employee_key = sf.employee_key 
     AND ed.manager_code1 > ?), -- 10 20 30 40 50 100 1000 5000 10000 100000
      inventory AS
  (SELECT if.*
   FROM go_branch_dim AS bd,
        dist_inventory_fact AS IF
   WHERE if.branch_key = bd.branch_key 
     AND bd.branch_code > ?) --  6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
SELECT sales.product_key AS prod_key,
       sum(CAST (inventory.quantity_shipped AS BIGINT)) AS inv_shipped,
       sum(CAST (sales.quantity AS BIGINT)) AS prod_quantity,
       rank() OVER (
                    ORDER BY sum(CAST (sales.quantity AS BIGINT)) DESC) AS prod_rank
FROM sales,
     inventory
WHERE sales.product_key = inventory.product_key
GROUP BY sales.product_key;
