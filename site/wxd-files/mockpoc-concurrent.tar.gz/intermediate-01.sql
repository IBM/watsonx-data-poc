-- intermediate-01.sql
-- retrieves aggregated sales metrics such as quantity, revenue, and gross profit
-- for different order method types and years

SELECT sls_order_method_dim.order_method_en AS order_method_typekey,
       go_time_dim.current_year AS yearkey, 
       sum(sls_sales_fact.quantity) AS quantity,
       sum(sls_sales_fact.sale_total) AS revenue,
       sum(sls_sales_fact.gross_profit) AS gross_profit
FROM sls_order_method_dim sls_order_method_dim,
     go_time_dim go_time_dim,
     sls_sales_fact sls_sales_fact
--WHERE (GO_TIME_DIM.CURRENT_YEAR in (2010, 2011, 2012))  
WHERE (GO_TIME_DIM.CURRENT_YEAR in (?, ?, ?)) -- 2009 2010 2011     2010 2011 2012
and (sls_sales_fact.order_method_key = sls_order_method_dim.order_method_key)
  AND (sls_sales_fact.order_day_key = go_time_dim.day_key)
GROUP BY sls_order_method_dim.order_method_en,
         go_time_dim.current_year;
