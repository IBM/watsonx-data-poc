-- simple-10.sql
-- retrieves sales-related information from the sls_sales_fact table,
-- including details such as order day, organization, employee, retailer, product, promotion, and more
-- to include only records from the year(s) months specified 

SELECT sls_sales_fact.order_day_key,
       sls_sales_fact.organization_key,
       sls_sales_fact.employee_key,
       sls_sales_fact.retailer_key,
       sls_sales_fact.retailer_site_key,
       sls_sales_fact.product_key,
       sls_sales_fact.promotion_key,
       sls_sales_fact.order_method_key,
       sls_sales_fact.sales_order_key,
       sls_sales_fact.ship_day_key,
       sls_sales_fact.close_day_key,
       sls_sales_fact.quantity,
       sls_sales_fact.unit_cost,
       sls_sales_fact.unit_price,
       sls_sales_fact.unit_sale_price,
       sls_sales_fact.gross_margin,
       sls_sales_fact.sale_total,
       sls_sales_fact.gross_profit
FROM sls_sales_fact,
     go_time_dim
WHERE sls_sales_fact.order_day_key = go_time_dim.day_key
  AND go_time_dim.current_year = 2010 -- 2007 2008 2009 2010 2011 2012
  AND go_time_dim.current_month = 1 -- 1 2 3 4 5 6 7 8 9 10 11 12
--limit 100
;
