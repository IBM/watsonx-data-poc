-- simple-03.sql
-- retrieve customer names and email addresses

SELECT e.employee_key,
       e.employee_name,
       e.manager_key,
       e.organization_code
FROM emp_employee_dim e
WHERE e.branch_code = 6 -- branch codes -> 6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
ORDER BY e.employee_name
--LIMIT 50
;
