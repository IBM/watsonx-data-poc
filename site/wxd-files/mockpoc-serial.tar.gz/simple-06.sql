-- simple-06.sql
-- count records from the GO_BRANCH_DIM and DIST_INVENTORY_FACT tables,
-- where the DIST_INVENTORY_FACT's BRANCH_KEY matches with GO_BRANCH_DIM's BRANCH_KEY, and
-- the GO_BRANCH_DIM's BRANCH_CODE is greater than some BD.BRANCH_CODE

SELECT count(*)
FROM go_branch_dim AS bd,
     dist_inventory_fact AS IF
WHERE if.branch_key = bd.branch_key
  AND bd.branch_code > 20 -- 6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
;
