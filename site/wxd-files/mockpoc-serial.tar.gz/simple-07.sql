-- simple-07.sql
-- retrieves specific columns from the GO_REGION_DIM table

SELECT country_key,
       country_code, -- FLAG_IMAGE,
 iso_three_letter_code,
 iso_two_letter_code,
 iso_three_digit_code,
 region_key,
 region_code,
 region_en
FROM go_region_dim
WHERE region_code = 740 --  710 740 750 760 770
LIMIT 100;
