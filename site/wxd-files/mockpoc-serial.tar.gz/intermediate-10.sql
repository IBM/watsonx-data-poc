-- intermediate-10.sql
-- gather and analyze sales and inventory data

WITH sales AS
  (SELECT sf.product_key AS sales_product_key,
          sf.quantity AS sales_quantity,
          sf.order_method_key AS sales_order_method_key
   FROM sls_sales_fact AS sf,
        sls_product_dim AS pd,
        sls_order_method_dim AS md,
        emp_employee_dim ed
   WHERE pd.product_key = sf.product_key
     AND pd.product_number > 10000 -- 100 1000 5000 10000 25000 50000 100000 150000
     AND pd.base_product_key > 30 -- 10 20 30 40 50 60 70 80 90 100
     AND md.order_method_key = sf.order_method_key
     AND md.order_method_code > 5 -- 1 2 3 4 5 6 7
     AND ed.employee_key = sf.employee_key
     AND ed.manager_code1 > 20), -- 10 20 30 40 50 100 1000 5000 10000 100000
      inventory AS
  (SELECT if.product_key AS inventory_product_key,
          if.quantity_shipped AS inventory_quantity_shipped
   FROM dist_inventory_fact AS IF,
        go_branch_dim AS bd
   WHERE if.branch_key = bd.branch_key
     AND bd.branch_code > 20) --  6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
SELECT sales.sales_product_key,
       sum(cast(inventory.inventory_quantity_shipped AS BIGINT)) AS total_quantity_shipped,
       sum(cast(sales.sales_quantity AS BIGINT)) AS total_sales_quantity
FROM sales,
     inventory
WHERE sales.sales_product_key = inventory.inventory_product_key
GROUP BY sales.sales_product_key
ORDER BY total_sales_quantity DESC;
