-- intermediate-08.sql
-- calculates the sum of quantities shipped and sold for products with specific criteria

WITH sales AS
  (SELECT sf.sales_order_key,
          sf.product_key,
          sf.quantity,
          sf.unit_cost,
          sf.unit_price,
          sf.unit_sale_price,
          sf.gross_margin,
          sf.sale_total,
          sf.gross_profit,
          sf.order_day_key,
          sf.order_method_key,
          sf.retailer_key,
          sf.retailer_site_key,
          sf.employee_key,
          sf.promotion_key,
          sf.ship_day_key,
          sf.close_day_key
   FROM sls_sales_fact AS sf
   JOIN sls_product_dim AS pd ON sf.product_key = pd.product_key
   JOIN sls_order_method_dim AS md ON sf.order_method_key = md.order_method_key
   JOIN emp_employee_dim AS ed ON sf.employee_key = ed.employee_key
   WHERE pd.product_number > 10000 -- 100 1000 5000 10000 25000 50000 100000 150000
     AND pd.base_product_key > 30 -- 10 20 30 40 50 60 70 80 90 100
     AND md.order_method_code > 5 -- 1 2 3 4 5 6 7
     AND ed.manager_code1 > 20 ), -- 10 20 30 40 50 100 1000 5000 10000 100000
      inventory AS
  (SELECT if.month_key,
          if.organization_key,
          if.branch_key,
          if.product_key,
          if.opening_inventory,
          if.quantity_shipped,
          if.additions,
          if.unit_cost,
          if.closing_inventory,
          if.average_unit_cost
   FROM dist_inventory_fact AS IF
   JOIN go_branch_dim AS bd ON if.branch_key = bd.branch_key
   WHERE bd.branch_code > 20 --  6 7 9 13 14 15 17 18 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 36 37 38 39 40
)
SELECT sales.product_key,
       sum(cast(inventory.quantity_shipped AS BIGINT)) AS total_quantity_shipped,
       sum(cast(sales.quantity AS BIGINT)) AS total_quantity_sold
FROM sales
JOIN inventory ON sales.product_key = inventory.product_key
GROUP BY sales.product_key;
