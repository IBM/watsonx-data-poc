-- intermediate-05.sql
-- average gross margin per product type, grouped by quarter and year:

SELECT pd.product_type_key,
       extract(QUARTER
               FROM g.day_date) AS QUARTER,
       extract(YEAR
               FROM g.day_date) AS YEAR,
       avg(sf.gross_margin) AS average_gross_margin
FROM sls_product_dim pd
JOIN sls_sales_fact sf ON pd.product_key = sf.product_key
JOIN go_time_dim g ON sf.order_day_key = g.day_key
WHERE extract(YEAR
              FROM g.day_date) = 2010 -- 2009 2010 2011 2012
GROUP BY pd.product_type_key,
         QUARTER,
         YEAR
ORDER BY YEAR,
         QUARTER;
