-- intermediate-07.sql
-- retrieves information about sales transactions, including product details and marketing promotions for a given languauge

SELECT product_name,
       sales.product_key,
       sales.quantity,
       mkt.order_day_key,
       sales.sales_order_key,
       order_method_en
FROM mrk_promotion_fact mkt ,
     sls_sales_fact sales ,
     sls_product_dim prod ,
     sls_product_lookup pnumb ,
     sls_order_method_dim meth
WHERE mkt.order_day_key=sales.order_day_key
  AND sales.product_key=prod.product_key
  AND prod.product_number=pnumb.product_number
  AND pnumb.product_language='EN' --IT EL TR SV SL ID TH MS HU RU PL KK AR NO HR DE RO FI NL FR JA TC CS EN SC DA KO PT ES
  AND meth.order_method_key=sales.order_method_key
  AND sales.order_method_key = 602 -- 602 606 604 605 603 601 607
  AND sales.quantity > 5000
--LIMIT 100 
;
