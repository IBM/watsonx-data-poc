-- intermediate-04.sql
-- gross profit by top 25 PRODUCT_KEY

SELECT sf.product_key,
       pl.product_name,
       sum(sf.gross_profit) AS total_gross_profit
FROM sls_sales_fact sf
JOIN sls_product_dim pd ON sf.product_key = pd.product_key
JOIN sls_product_lookup pl ON pd.product_number = pl.product_number
GROUP BY sf.product_key,
         pl.product_name
ORDER BY total_gross_profit DESC
LIMIT 25;
