-- simple-05.sql
-- count number of products by PRODUCT_BRAND_CODE

SELECT product_brand_code,
       count(*) AS product_count
FROM sls_product_dim
GROUP BY product_brand_code;
