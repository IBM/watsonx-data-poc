-- intermediate-03.sql
-- count the number of orders and sum all orders by WAREHOUSE_BRANCH_CODE

SELECT warehouse_branch_code,
       count(*) AS order_count,
       sum(order_number) AS total_order_sum
FROM sls_sales_order_dim
GROUP BY GROUPING sets(warehouse_branch_code)
ORDER BY total_order_sum DESC ;
