-- intermediate-06.sql
-- count records from the SLS_ORDER_METHOD_DIM, SLS_PRODUCT_DIM, EMP_EMPLOYEE_DIM, and SLS_SALES_FACT tables
-- matching PRODUCT_KEY between SLS_PRODUCT_DIM and SLS_SALES_FACT
 
SELECT count(*) 
FROM sls_order_method_dim AS md, 
     sls_product_dim AS pd, 
     emp_employee_dim AS ed, 
     sls_sales_fact AS sf 
WHERE pd.product_key = sf.product_key 
  AND pd.product_number > 10000 -- 100 1000 5000 10000 25000 50000 100000 150000
  AND pd.base_product_key > 30 -- 10 20 30 40 50 60 70 80 90 100
  AND md.order_method_key = sf.order_method_key 
  AND ed.employee_key = sf.employee_key 
  AND ed.manager_code1 > 20 -- 10 20 30 40 50 100 1000 5000 10000 100000
  AND md.order_method_code > 5 -- 1 2 3 4 5 6 7
