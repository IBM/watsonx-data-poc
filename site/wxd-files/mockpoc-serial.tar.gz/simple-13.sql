-- simple-13.sql
-- number of products introduced by year

SELECT extract(YEAR
               FROM introduction_date) AS introduction_year,
       count(*) AS product_count
FROM sls_product_dim
GROUP BY introduction_year
ORDER BY introduction_year;
